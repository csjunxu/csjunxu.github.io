==============================================================
Freiburg-Berkeley Motion Segmentation Dataset (Part)
==============================================================

Database description
--------------------
This dataset contains 137 motion sequences which, 22 of which are rigid motion sequences 
and 115 of which are non-rigid motion sequences. The original Freiburg-Berkeley Motion 
Segmentation Dataset 59 motion videos with pixel-accurate segmentation annotation of 
moving objects. 42 of the 59 videos describe animal's moving, which is clearly non-rigid. 
11 videos describe vehicle's moving and the 450 last 6 videos decribe people's motions, 
such as walking, talking, and playing tennis, which are also non-rigid. 12 of the 59 
sequences (including 10 sequences describing cars moving, which are rigid motions and 2 
sequences describing people walking) are taken from the Hopkins155 dataset[7]. Since the 
tracked feature points in a video sequence consists of multiple frames such as 10 frames, 
455 50 frames, and 200 frames, we can get more than 59 motion sequences. 

File format
-----------

Each sequence is contained in a directory having the corresponding
name.  In each directory there is a Matlab 6 .MAT file containing the ground-truth.

The variables inside the ground-truth file are organized as follow:
. width and height: dimensions (in pixels) of all the frames in the
  video sequence.
. points: number of tracked points P.
. frames: number of frames F.
. y: a matrix 3xPxF containing the homogeneous coordinates of the P
  points in the F frames.
. x: a matrix 3xPxF derived from y by normalizing the first two
  components of each vector such that they belong to the interval
  [-1;1].
. K: the 3x3 normalization matrix used to pass from y to x
  (x=K^(-1)*x).
. s: a Px1 vector containing the ground-truth segmentation; for each
  point it gives the index of the corresponding motion group.

References
----------
[1] T. Brox, J. Malik. Object segmentation by long term analysis of point trajectories, 
      European Conference on Computer Vision (ECCV), September 2010.

[2] P. Ochs, J. Malik, T. Brox. Segmentation of moving objects by long term video analysis, 
      IEEE Transactions on Pattern Analysis and Machine Intelligence, 2014.